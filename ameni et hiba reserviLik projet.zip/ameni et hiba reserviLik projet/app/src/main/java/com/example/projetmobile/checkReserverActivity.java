package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class checkReserverActivity extends AppCompatActivity {
 TextView comm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_reserver);
        comm=findViewById(R.id.reserverChecked);
        Intent intentAbn =getIntent();
        String trans=intentAbn.getStringExtra("transport");
        String user=intentAbn.getStringExtra("username");
        String pos=intentAbn.getStringExtra("position");
        String dest=intentAbn.getStringExtra("destination");
        String date=intentAbn.getStringExtra("date");
        String min=intentAbn.getStringExtra("min");
        String heure =intentAbn.getStringExtra("heure");
        comm.setText("Bienvenue  "+user + "  vous etes reservé au moyen de transport "+trans+"\n"+"de "+pos +"---->"+dest
                +"\n  le "+date +"à "+heure+":"+min+"  \n votre reservation va etre expire apres 3 heures " +"\n votre QRC est :");
    }
}