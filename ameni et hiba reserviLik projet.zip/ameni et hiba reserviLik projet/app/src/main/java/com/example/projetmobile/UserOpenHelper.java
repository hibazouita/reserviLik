package com.example.projetmobile;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UserOpenHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "User_Manager";

    // Table name: user.
    private static final String TABLE_USER = "Users";

    private static final String COLUMN_USER_ID = "User_Id";
    private static final String COLUMN_USER_NAME = "User_name";
    private static final String COLUMN_USER_CIN = "User_CIN";
    private static final String COLUMN_USER_PASS1 = "User_Password";


    private static final int COLUMN_USER_ID_NUM = 0;
    private static final int COLUMN_USER_NAME_NUM = 1;
    private static final int COLUMN_USER_CIN_NUM = 2;
    private static final int COLUMN_USER_PASS1_NUM = 3;


    // Script to create table.
    private static final String REQUETE_CREATION_TABLE_USER = "CREATE TABLE " + TABLE_USER
            + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY,"
            + COLUMN_USER_NAME + " TEXT,"
            + COLUMN_USER_CIN + "INTEGER,"
            + COLUMN_USER_PASS1 + " TEXT"
            + ")";

    public UserOpenHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // Execute script.
        sqLiteDatabase.execSQL(REQUETE_CREATION_TABLE_USER);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Drop table
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);


        // Recreate
        onCreate(sqLiteDatabase);

    }


    public static int getDatabaseVersion() {
        return DATABASE_VERSION;
    }

    public static int getColumnUserPass1Num() {
        return COLUMN_USER_PASS1_NUM;
    }

    public static int getColumnUserNameNum() {
        return COLUMN_USER_NAME_NUM;
    }

    public static String getColumnUserCin() {
        return COLUMN_USER_CIN;
    }

    public static String getColumnUserId() {
        return COLUMN_USER_ID;
    }


    public static String getRequeteCreationTableUser() {
        return REQUETE_CREATION_TABLE_USER;
    }
}

