package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class inscActivity extends AppCompatActivity {
    EditText username,password1,password2,cin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insc);
        username=findViewById(R.id.username);
        password1=findViewById(R.id.password1);
        password2=findViewById(R.id.password2);

    }
    public void validerInscrit(View view) {
        String user=username.getText().toString();
        String pw1=password1.getText().toString();
        String pw2=password2.getText().toString();
        Intent intentInscrit=new Intent(this,checkedSignUpActivity.class);
        Intent intentErreur=new Intent(this,errorActivity.class);
        if (pw1.equals(pw2)){
            intentInscrit.putExtra("username",user);
            startActivity(intentInscrit);
        }
        else{
            startActivity(intentErreur);

        }


    }
}

