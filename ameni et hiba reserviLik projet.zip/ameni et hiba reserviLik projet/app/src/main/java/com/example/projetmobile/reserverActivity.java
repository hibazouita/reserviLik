package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class reserverActivity extends AppCompatActivity {
    EditText username,transport,date,position,destination,heure,minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserver);
        username=findViewById(R.id.username);
        transport=findViewById(R.id.moyen);
       date=findViewById(R.id.date);
        position=findViewById(R.id.pos);
        destination=findViewById(R.id.dest);
        heure=findViewById(R.id.heurebn);
        minute=findViewById(R.id.minute);

    }

    public void validerRes(View view) {
        Intent intentRes=new Intent(this,checkReserverActivity.class);
        String user=username.getText().toString();
        String trans=transport.getText().toString();
        String pos=position.getText().toString();
        String dest=destination.getText().toString();
        String day=date.getText().toString();
        String heur=heure.getText().toString();
        String min=minute.getText().toString();
        intentRes.putExtra("username", user);
        intentRes.putExtra("transport",trans );
        intentRes.putExtra("position",pos);
        intentRes.putExtra("destination",dest);
        intentRes.putExtra("date",day);
        intentRes.putExtra("heure",heur);
        intentRes.putExtra("min",min);
        startActivity(intentRes);
    }
}