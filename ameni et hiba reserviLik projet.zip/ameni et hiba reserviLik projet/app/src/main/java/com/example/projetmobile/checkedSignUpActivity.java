package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class checkedSignUpActivity extends AppCompatActivity {
    TextView res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checked_sign_up);
        res=findViewById(R.id.comptecrée);
        Intent intentInscrit =getIntent();
        String user= intentInscrit.getStringExtra("username");
        res.setText("bienvuenue "+user +"\n votre compte a été créer avec succès!!!");

    }
}
