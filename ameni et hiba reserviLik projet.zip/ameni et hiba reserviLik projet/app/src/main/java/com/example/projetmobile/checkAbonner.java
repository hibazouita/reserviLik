package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class checkAbonner extends AppCompatActivity {
    TextView comm;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_abonner);
        comm=findViewById(R.id.abonnerchecked);
        Intent intentAbn =getIntent();
        String trans=intentAbn.getStringExtra("transport");
        String user=intentAbn.getStringExtra("username");
        String pos=intentAbn.getStringExtra("position");
        String dest=intentAbn.getStringExtra("destination");
        String periode =intentAbn.getStringExtra("periode");
        comm.setText("Bienvenue  "+user + "  vous etes reserves au moyen de transport "+trans+"\n"+"de "+pos +"---->"+dest
        +"\n votre abonnement va etre expire "+periode +"\n votre QRC est :");





    }
}
