package com.example.projetmobile;

public class User {
    private static int ID;



    private String username;
    private String cin;
    private String pwd;

    public User() {

    }
    public  User(String user,String cin,String pwd){
         this.ID++;
         this.username=user;
         this.cin=cin;
         this.pwd=pwd;

    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public static int getID() {
        return ID;
    }

    public static void setID(int ID) {
        User.ID = ID;
    }
}
