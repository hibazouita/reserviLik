package com.example.projetmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

public class abonnerActivity extends AppCompatActivity {
    EditText username,mail,cin,transport,jour,moiss,annee,destination,position;
    RadioButton mois,semestre,annee2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abonner);
         username=findViewById(R.id.username);
          mail=findViewById(R.id.mail);
        cin=findViewById(R.id.cin);
        transport=findViewById(R.id.moyen);
      jour=findViewById(R.id.jour);
        moiss=findViewById(R.id.moiss);
        annee=findViewById(R.id.anne);
       position=findViewById(R.id.pos);
        destination=findViewById(R.id.dest);
       mois=findViewById(R.id.mois);
         semestre=findViewById(R.id.semestre);
         annee2=findViewById(R.id.annee);
    }

    public void validerabn(View view) {
        Intent intentabn=new Intent(this,checkAbonner.class);
        String user=username.getText().toString();
        String trans=transport.getText().toString();
        String pos=position.getText().toString();
        String dest=destination.getText().toString();
        intentabn.putExtra("username", user);
        String periode="";
        intentabn.putExtra("transport",trans );
        intentabn.putExtra("position",pos);
        intentabn.putExtra("destination",dest);

        if(mois.isChecked()){
             periode = "30 jours";
        }
        if (semestre.isChecked()){
            periode = "6 mois";
        }
        if(annee2.isChecked()){
            periode = "une annee";

        }
        intentabn.putExtra("periode",periode);
        startActivity(intentabn);
    }

}
